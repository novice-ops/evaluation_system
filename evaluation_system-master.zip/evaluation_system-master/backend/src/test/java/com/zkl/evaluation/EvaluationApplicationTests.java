package com.zkl.evaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvaluationApplicationTests {

	@Test
	void contextLoads() {
	}

}
