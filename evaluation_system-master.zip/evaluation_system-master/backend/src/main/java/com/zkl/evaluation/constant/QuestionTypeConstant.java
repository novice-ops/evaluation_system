package com.zkl.evaluation.constant;

/**
 * 题型常量
 */
public interface QuestionTypeConstant {
    String Unknown = "unknown";

    String Single = "single";

    String Multiple = "multi";

    String Fill = "fill";

    String Subjective = "subjective";
}
