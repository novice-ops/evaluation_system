package com.zkl.evaluation.service.impl;

import com.alibaba.excel.util.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zkl.evaluation.common.ErrorCode;
import com.zkl.evaluation.constant.CommonConstant;
import com.zkl.evaluation.exception.BusinessException;
import com.zkl.evaluation.model.dto.apiLog.ApiLogQueryRequest;
import com.zkl.evaluation.model.entity.ApiLog;
import com.zkl.evaluation.service.ApiLogService;
import com.zkl.evaluation.mapper.ApiLogMapper;
import com.zkl.evaluation.utils.SqlUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
* @author zkl
* @description 针对表【api_log(接口调用请求日志)】的数据库操作Service实现
* @createDate 2025-04-16 20:37:25
*/
@Service
public class ApiLogServiceImpl extends ServiceImpl<ApiLogMapper, ApiLog>
    implements ApiLogService{

    @Resource
    private ApiLogMapper apiLogMapper;

    @Override
    public QueryWrapper<ApiLog> getQueryWrapper(ApiLogQueryRequest apiLogQueryRequest) {
        if(apiLogQueryRequest == null){
            throw new BusinessException(ErrorCode.PARAMS_ERROR,"请求参数为空");
        }
        Long id = apiLogQueryRequest.getId();
        String ip = apiLogQueryRequest.getIp();
        String path = apiLogQueryRequest.getPath();
        Long userId = apiLogQueryRequest.getUserId();
        String sortField = apiLogQueryRequest.getSortField();
        String sortOrder = apiLogQueryRequest.getSortOrder();
        QueryWrapper<ApiLog> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(id != null, "id", id);
        queryWrapper.eq(StringUtils.isNotBlank(ip), "ip", ip);
        queryWrapper.eq(StringUtils.isNotBlank(path), "path", path);
        queryWrapper.eq(userId != null, "userId", userId);
        queryWrapper.orderBy(SqlUtils.validSortField(sortField), sortOrder.equals(CommonConstant.SORT_ORDER_ASC),
                sortField);
        return null;
    }

    @Override
    public ApiLog getByRequestId(String requestId) {
        return apiLogMapper.getByRequestId(requestId);
    }

    @Override
    public boolean removeByRequestId(String requestId) {
        return apiLogMapper.removeByRequestId(requestId);
    }
}




