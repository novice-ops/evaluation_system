package com.zkl.evaluation.service;

import com.zkl.evaluation.model.entity.QuestionTag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author zkl
* @description 针对表【question_tag(题目标签)】的数据库操作Service
* @createDate 2025-04-16 20:37:25
*/
public interface QuestionTagService extends IService<QuestionTag> {

}
