package com.zkl.evaluation.mapper;

import com.zkl.evaluation.model.entity.ApiLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
* @author zkl
* @description 针对表【api_log(接口调用请求日志)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.ApiLog
*/
public interface ApiLogMapper extends BaseMapper<ApiLog> {

    @Select("select * from api_log where requestId = #{requestId}")
    ApiLog getByRequestId(@Param("requestId")String requestId);

    @Delete("delete from api_log where requestId = #{requestId}")
    boolean removeByRequestId(@Param("requestId")String requestId);
}




