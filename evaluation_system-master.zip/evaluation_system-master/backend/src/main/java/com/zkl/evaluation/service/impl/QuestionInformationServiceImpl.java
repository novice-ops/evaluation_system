package com.zkl.evaluation.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zkl.evaluation.service.QuestionInformationService;
import com.zkl.evaluation.model.entity.QuestionInformation;
import com.zkl.evaluation.mapper.QuestionInformationMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
* @author zkl
* @description 针对表【question_information(题目信息)】的数据库操作Service实现
* @createDate 2025-04-16 20:37:25
*/
@Service
public class QuestionInformationServiceImpl extends ServiceImpl<QuestionInformationMapper, QuestionInformation>
    implements QuestionInformationService {

    @Override
    public String getQuestionTypeByAppId(long appId) {
        return baseMapper.getQuestionTypeByAppId(appId);
    }

    @Override
    public boolean removeByQuestionId(long id) {
        return baseMapper.removeByQuestionId(id);
    }


}




