package com.zkl.evaluation.controller;

import com.zkl.evaluation.common.BaseResponse;
import com.zkl.evaluation.common.ErrorCode;
import com.zkl.evaluation.common.ResultUtils;
import com.zkl.evaluation.constant.QuestionTypeConstant;
import com.zkl.evaluation.exception.ThrowUtils;
import com.zkl.evaluation.model.entity.App;
import com.zkl.evaluation.model.entity.QuestionInformation;
import com.zkl.evaluation.model.vo.AppVO;
import com.zkl.evaluation.model.vo.QuestionInformationVO;
import com.zkl.evaluation.service.QuestionInformationService;
import com.zkl.evaluation.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 题目信息接口
 *

 */
@RestController
@RequestMapping("/questionInformation")
@Slf4j
public class QuestionInformationController {

    @Resource
    private QuestionInformationService questionInformationService;

    @Resource
    private UserService userService;


//    @GetMapping("/get/vo")
//    public BaseResponse<QuestionInformationVO> getAppVOById(long id, HttpServletRequest request) {
//        ThrowUtils.throwIf(id <= 0, ErrorCode.PARAMS_ERROR);
//        // 查询数据库
//        QuestionInformation questionInformation = questionInformationService.getById(id);
//        ThrowUtils.throwIf(questionInformation == null, ErrorCode.NOT_FOUND_ERROR);
//        // 获取封装类
//        return ResultUtils.success(questionInformationService.getQuestionInformationVO(questionInformation, request));
//    }

    @GetMapping("/get/appId")
    public BaseResponse<String> getQuestionTypeByAppId(@RequestParam("appId") long appId,
                                                          HttpServletRequest request) {
        ThrowUtils.throwIf(appId <= 0, ErrorCode.PARAMS_ERROR);
        // 查询数据库
        String type = questionInformationService.getQuestionTypeByAppId(appId);
        if(type == null){
            return ResultUtils.success(QuestionTypeConstant.Unknown);
        }
        return ResultUtils.success(type);
    }

}
