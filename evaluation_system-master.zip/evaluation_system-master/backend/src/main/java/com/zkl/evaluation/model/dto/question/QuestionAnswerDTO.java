package com.zkl.evaluation.model.dto.question;

import lombok.Data;

import java.util.List;

/**
 * 题目答案封装类（用于 AI 评分）
 *
 */
@Data
public class QuestionAnswerDTO {

    /**
     * 题目
     */
    private String title;

    private String type;

    private List<?> correct;

    /**
     * 用户答案
     */
    private String userAnswer;
}
