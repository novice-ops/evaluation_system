package com.zkl.evaluation.controller;

import com.zkl.evaluation.common.BaseResponse;
import com.zkl.evaluation.exception.ThrowUtils;
import com.zkl.evaluation.service.QuestionTagService;
import com.zkl.evaluation.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 题目标签接口
 *

 */
@RestController
@RequestMapping("/questionTag")
@Slf4j
public class QuestionTagController {

    @Resource
    private QuestionTagService questionTagService;

    @Resource
    private UserService userService;

}
