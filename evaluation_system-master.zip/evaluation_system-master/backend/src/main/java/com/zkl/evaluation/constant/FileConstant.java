package com.zkl.evaluation.constant;

/**
 * 文件常量
 *

 */
public interface FileConstant {

    /**
     * COS 访问地址
     */
//    String COS_HOST = "https://evaluation-system-1321264031.cos.ap-shanghai.myqcloud.com";
    String COS_HOST = "https://evaluation-system-1321264031.cos-website.ap-shanghai.myqcloud.com";
}

