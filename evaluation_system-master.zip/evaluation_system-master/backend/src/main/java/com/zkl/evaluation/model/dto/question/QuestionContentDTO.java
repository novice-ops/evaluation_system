package com.zkl.evaluation.model.dto.question;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class QuestionContentDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private String title;  // 题目内容

    private List<Option> options;  // 单选或多选题的选项

    private List<Answer> answers;  // 填空或简答题的参考答案

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Option {
        private String result;
        private int score;
        private String value;
        private String key;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Answer {
        private String result;
        private int score;
        private String value;
        private String key;
    }
}
