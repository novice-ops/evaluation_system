package com.zkl.evaluation.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.zkl.evaluation.model.dto.apiLog.ApiLogQueryRequest;
import com.zkl.evaluation.model.entity.ApiLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author zkl
* @description 针对表【api_log(接口调用请求日志)】的数据库操作Service
* @createDate 2025-04-16 20:37:25
*/
public interface ApiLogService extends IService<ApiLog> {

    QueryWrapper<ApiLog> getQueryWrapper(ApiLogQueryRequest apiLogQueryRequest);

    ApiLog getByRequestId(String requestId);

    boolean removeByRequestId(String requestId);
}
