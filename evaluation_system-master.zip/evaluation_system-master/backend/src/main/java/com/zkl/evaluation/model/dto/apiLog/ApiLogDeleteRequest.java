package com.zkl.evaluation.model.dto.apiLog;

import lombok.Data;

import java.io.Serializable;

/**
 * @author : zkl
 * @description :
 */
@Data
public class ApiLogDeleteRequest implements Serializable {
    private String requestId;

    private static final long serialVersionUID = 1L;
}
