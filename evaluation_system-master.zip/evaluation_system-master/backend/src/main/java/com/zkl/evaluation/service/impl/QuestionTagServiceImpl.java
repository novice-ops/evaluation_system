package com.zkl.evaluation.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.zkl.evaluation.service.QuestionTagService;
import com.zkl.evaluation.model.entity.QuestionTag;
import com.zkl.evaluation.mapper.QuestionTagMapper;
import org.springframework.stereotype.Service;

/**
* @author zkl
* @description 针对表【question_tag(题目标签)】的数据库操作Service实现
* @createDate 2025-04-16 20:37:25
*/
@Service
public class QuestionTagServiceImpl extends ServiceImpl<QuestionTagMapper, QuestionTag>
    implements QuestionTagService {

}




