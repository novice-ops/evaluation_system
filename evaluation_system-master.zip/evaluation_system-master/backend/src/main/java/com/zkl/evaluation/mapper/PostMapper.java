package com.zkl.evaluation.mapper;

import com.zkl.evaluation.model.entity.Post;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;
import java.util.List;

/**
* @author zkl
* @description 针对表【post(帖子)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.Post
*/
public interface PostMapper extends BaseMapper<Post> {

    List<Post> listPostWithDelete(Date minUpdateTime);
}




