package com.zkl.evaluation.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zkl.evaluation.model.entity.Post;
import com.zkl.evaluation.model.entity.PostFavour;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
* @author zkl
* @description 针对表【post_favour(帖子收藏)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.PostFavour
*/
public interface PostFavourMapper extends BaseMapper<PostFavour> {

    Page<Post> listFavourPostByPage(IPage<Post> page, @Param(Constants.WRAPPER) Wrapper<Post> queryWrapper,
                                    @Param("favourUserId") long favourUserId);
}




