package com.zkl.evaluation.model.dto.apiLog;

import com.zkl.evaluation.common.PageRequest;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 接口日志查询请求
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ApiLogQueryRequest extends PageRequest implements Serializable {
    /**
     * id
     */
    private Long id;
    /**
     *
     */
    private String ip;
    /**
     *
     */
    private String path;
    /**
     * 创建用户 id
     */
    private Long userId;

    private static final long serialVersionUID = 1L;
}
