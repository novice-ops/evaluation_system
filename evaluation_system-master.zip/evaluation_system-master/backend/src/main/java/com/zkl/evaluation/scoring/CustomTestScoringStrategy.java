package com.zkl.evaluation.scoring;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.zkl.evaluation.model.dto.question.QuestionContentDTO;
import com.zkl.evaluation.model.entity.App;
import com.zkl.evaluation.model.entity.Question;
import com.zkl.evaluation.model.entity.ScoringResult;
import com.zkl.evaluation.model.entity.UserAnswer;
import com.zkl.evaluation.model.vo.QuestionVO;
import com.zkl.evaluation.service.QuestionInformationService;
import com.zkl.evaluation.service.QuestionService;
import com.zkl.evaluation.service.ScoringResultService;


import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 自定义测评类应用评分策略
 *
 */
@ScoringStrategyConfig(appType = 1, scoringStrategy = 0)
public class CustomTestScoringStrategy implements ScoringStrategy {

    @Resource
    private QuestionService questionService;

    @Resource
    private ScoringResultService scoringResultService;

    @Resource
    private QuestionInformationService questionInformationService;

    @Override
    public UserAnswer doScore(List<String> choices, App app) throws Exception {
        Long appId = app.getId();
        // 1. 根据 id 查询到题目和题目结果信息
        Question question = questionService.getOne(
                Wrappers.lambdaQuery(Question.class).eq(Question::getAppId, appId)
        );
        List<ScoringResult> scoringResultList = scoringResultService.list(
                Wrappers.lambdaQuery(ScoringResult.class)
                        .eq(ScoringResult::getAppId, appId)
        );
        String type = questionInformationService.getQuestionTypeByAppId(appId);

        // 2. 统计用户每个选择对应的属性个数，如 I = 10 个，E = 5 个
        // 初始化一个Map，用于存储每个选项的计数
        Map<String, Integer> optionCount = new HashMap<>();

        QuestionVO questionVO = QuestionVO.objToVo(question);
        List<QuestionContentDTO> questionContent = questionVO.getQuestionContent();

        // 遍历题目列表
        for (QuestionContentDTO questionContentDTO : questionContent) {
            if ("single".equals(type) || "multi".equals(type)) {
                // 处理单选题和多选题
                calculateChoiceScore(questionContentDTO, choices, optionCount);
            } else if ("fill".equals(type) || "subjective".equals(type)) {
                // 处理填空题和简答题
                calculateTextAnswerScore(questionContentDTO, choices, optionCount);
            }
        }

        // 3. 遍历每种评分结果，计算哪个结果的得分更高
        // 初始化最高分数和最高分数对应的评分结果
        int maxScore = 0;
        ScoringResult maxScoringResult = scoringResultList.get(0);

        // 遍历评分结果列表
        for (ScoringResult scoringResult : scoringResultList) {
            List<String> resultProp = JSONUtil.toList(scoringResult.getResultProp(), String.class);
            // 计算当前评分结果的分数，[I, E] => [10, 5] => 15
            int score = resultProp.stream()
                    .mapToInt(prop -> optionCount.getOrDefault(prop, 0))
                    .sum();

            // 如果分数高于当前最高分数，更新最高分数和最高分数对应的评分结果
            if (score > maxScore) {
                maxScore = score;
                maxScoringResult = scoringResult;
            }
        }

        // 4. 构造返回值，填充答案对象的属性
        UserAnswer userAnswer = new UserAnswer();
        userAnswer.setAppId(appId);
        userAnswer.setAppType(app.getAppType());
        userAnswer.setScoringStrategy(app.getScoringStrategy());
        userAnswer.setChoices(JSONUtil.toJsonStr(choices));
        userAnswer.setResultId(maxScoringResult.getId());
        userAnswer.setResultName(maxScoringResult.getResultName());
        userAnswer.setResultDesc(maxScoringResult.getResultDesc());
        userAnswer.setResultPicture(maxScoringResult.getResultPicture());
        return userAnswer;
    }

    /**
     * 计算单选题和多选题的得分
     *
     * @param questionContentDTO 题目内容
     * @param choices 用户选择的答案
     * @param optionCount 用于存储各个选项的计数
     */
    private void calculateChoiceScore(QuestionContentDTO questionContentDTO, List<String> choices, Map<String, Integer> optionCount) {
        for (String answer : choices) {
            for (QuestionContentDTO.Option option : questionContentDTO.getOptions()) {
                if (option.getKey().equals(answer)) {
                    String result = option.getResult();
                    optionCount.put(result, optionCount.getOrDefault(result, 0) + 1);
                }
            }
        }
    }

    /**
     * 计算填空题和简答题的得分
     *
     * @param questionContentDTO 题目内容
     * @param choices 用户输入的答案
     * @param optionCount 用于存储各个答案的计数
     */
    private void calculateTextAnswerScore(QuestionContentDTO questionContentDTO, List<String> choices, Map<String, Integer> optionCount) {
        for (int i = 0; i < choices.size(); i++) {
            String answer = choices.get(i);
            for (QuestionContentDTO.Answer refAnswer : questionContentDTO.getAnswers()) {
                // 简单的包含判断，如果填空答案包含参考答案，就给分
                if (answer.contains(refAnswer.getValue())) {
                    optionCount.put(refAnswer.getResult(), optionCount.getOrDefault(refAnswer.getResult(), 0) + 1);
                }
            }
        }
    }
}
