package com.zkl.evaluation.controller;

import com.zkl.evaluation.common.BaseResponse;
import com.zkl.evaluation.common.ErrorCode;
import com.zkl.evaluation.common.ResultUtils;
import com.zkl.evaluation.exception.BusinessException;
import com.zkl.evaluation.model.dto.postThumb.PostThumbAddRequest;
import com.zkl.evaluation.model.entity.User;
import com.zkl.evaluation.service.PostThumbService;
import com.zkl.evaluation.service.UserService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 帖子点赞接口
 *

 */
@RestController
@RequestMapping("/postThumb")
@Slf4j
public class PostThumbController {

    @Resource
    private PostThumbService postThumbService;

    @Resource
    private UserService userService;

    /**
     * 点赞 / 取消点赞
     *
     * @param postThumbAddRequest
     * @param request
     * @return resultNum 本次点赞变化数
     */
    @PostMapping("/")
    public BaseResponse<Integer> doThumb(@RequestBody PostThumbAddRequest postThumbAddRequest,
                                         HttpServletRequest request) {
        if (postThumbAddRequest == null || postThumbAddRequest.getPostId() <= 0) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        // 登录才能点赞
        final User loginUser = userService.getLoginUser(request);
        long postId = postThumbAddRequest.getPostId();
        int result = postThumbService.doPostThumb(postId, loginUser);
        return ResultUtils.success(result);
    }
}
