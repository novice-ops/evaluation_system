package com.zkl.evaluation.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zkl.evaluation.model.dto.question.QuestionQueryRequest;
import com.zkl.evaluation.model.entity.Question;
import com.baomidou.mybatisplus.extension.service.IService;
import com.zkl.evaluation.model.vo.QuestionVO;

import javax.servlet.http.HttpServletRequest;

/**
* @author zkl
* @description 针对表【question(题目)】的数据库操作Service
* @createDate 2025-04-16 20:37:25
*/
public interface QuestionService extends IService<Question> {
    /**
     * 校验数据
     *
     * @param question
     * @param add 对创建的数据进行校验
     */
    void validQuestion(Question question, boolean add);

    /**
     * 获取查询条件
     *
     * @param questionQueryRequest
     * @return
     */
    QueryWrapper<Question> getQueryWrapper(QuestionQueryRequest questionQueryRequest);

    /**
     * 获取题目封装
     *
     * @param question
     * @param request
     * @return
     */
    QuestionVO getQuestionVO(Question question, HttpServletRequest request);

    /**
     * 分页获取题目封装
     *
     * @param questionPage
     * @param request
     * @return
     */
    Page<QuestionVO> getQuestionVOPage(Page<Question> questionPage, HttpServletRequest request);

}
