package com.zkl.evaluation.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.zkl.evaluation.annotation.AuthCheck;
import com.zkl.evaluation.common.BaseResponse;
import com.zkl.evaluation.common.DeleteRequest;
import com.zkl.evaluation.common.ErrorCode;
import com.zkl.evaluation.common.ResultUtils;
import com.zkl.evaluation.constant.UserConstant;
import com.zkl.evaluation.exception.BusinessException;
import com.zkl.evaluation.exception.ThrowUtils;
import com.zkl.evaluation.model.dto.apiLog.ApiLogDeleteRequest;
import com.zkl.evaluation.model.dto.apiLog.ApiLogQueryRequest;
import com.zkl.evaluation.model.dto.user.UserQueryRequest;
import com.zkl.evaluation.model.entity.ApiLog;
import com.zkl.evaluation.model.entity.App;
import com.zkl.evaluation.model.entity.User;
import com.zkl.evaluation.service.ApiLogService;
import com.zkl.evaluation.service.UserService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

/**
 * 接口调用日志记录接口
 *
 */
@RestController
@RequestMapping("/apiLog")
@Slf4j
public class ApiLogController {

    @Resource
    private ApiLogService apiLogService;

    @Resource
    private UserService userService;

    /**
     * 分页获取最新接口调用日志记录（管理员）
     * @param apiLogQueryRequest
     * @param request
     * @return
     */
    @PostMapping("/list/page")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<Page<ApiLog>> listApiLogByPage(@RequestBody ApiLogQueryRequest apiLogQueryRequest,
                                                   HttpServletRequest request) {
        long current = apiLogQueryRequest.getCurrent();
        long size = apiLogQueryRequest.getPageSize();
        Page<ApiLog> apiLogPage = apiLogService.page(new Page<>(current, size),
                apiLogService.getQueryWrapper(apiLogQueryRequest));
        return ResultUtils.success(apiLogPage);
    }

    /**
     * 删除接口调用记录
     * @param deleteRequest
     * @param request
     * @return
     */
    @PostMapping("/delete")
    public BaseResponse<Boolean> deleteApp(@RequestBody ApiLogDeleteRequest deleteRequest, HttpServletRequest request) {
        if (deleteRequest == null || deleteRequest.getRequestId() == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        User user = userService.getLoginUser(request);
        if (user == null || user.getId() == null) {
            throw new BusinessException(ErrorCode.NOT_LOGIN_ERROR);
        }
        String requestId = deleteRequest.getRequestId();
        // 判断是否存在
//        ApiLog apiLog = apiLogService.getById(id);
        ApiLog apiLog = apiLogService.getByRequestId(requestId);
        ThrowUtils.throwIf(apiLog == null, ErrorCode.NOT_FOUND_ERROR);
        // 仅管理员可删除
        if (!userService.isAdmin(request)) {
            throw new BusinessException(ErrorCode.NO_AUTH_ERROR);
        }
        // 操作数据库
//        boolean result = apiLogService.removeById(id);
        boolean result = apiLogService.removeByRequestId(requestId);
        ThrowUtils.throwIf(!result, ErrorCode.OPERATION_ERROR);
        return ResultUtils.success(true);
    }

    /**
     * 通过requestId查询接口调用记录
     * @param requestId
     * @param request
     * @return
     */
    @GetMapping("/get")
    @AuthCheck(mustRole = UserConstant.ADMIN_ROLE)
    public BaseResponse<ApiLog> getApiLogByRequestId(String requestId, HttpServletRequest request) {
        if (requestId == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        ApiLog apiLog = apiLogService.getByRequestId(requestId);
        ThrowUtils.throwIf(apiLog == null, ErrorCode.NOT_FOUND_ERROR);
        return ResultUtils.success(apiLog);
    }

}
