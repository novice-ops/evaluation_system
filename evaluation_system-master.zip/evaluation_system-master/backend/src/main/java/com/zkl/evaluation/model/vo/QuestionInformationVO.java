package com.zkl.evaluation.model.vo;

/**
 * @author : zkl
 * @description :
 */

import lombok.Data;

/**
 * 问题信息视图
 */
@Data
public class QuestionInformationVO {
}
