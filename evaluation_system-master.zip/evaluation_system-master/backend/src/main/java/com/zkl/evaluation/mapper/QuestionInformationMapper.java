package com.zkl.evaluation.mapper;

import com.zkl.evaluation.model.entity.QuestionInformation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Update;

/**
* @author zkl
* @description 针对表【question_information(题目信息)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.QuestionInformation
*/
public interface QuestionInformationMapper extends BaseMapper<QuestionInformation> {

    String getQuestionTypeByAppId(long appId);

    @Update("update question_information set isDelete = 1 where questionId = #{id}")
    boolean removeByQuestionId(long id);
}




