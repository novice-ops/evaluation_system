package com.zkl.evaluation.mapper;

import com.zkl.evaluation.model.entity.App;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zkl
* @description 针对表【app(应用)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.App
*/
public interface AppMapper extends BaseMapper<App> {

}




