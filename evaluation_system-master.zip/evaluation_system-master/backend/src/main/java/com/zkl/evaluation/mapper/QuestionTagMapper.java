package com.zkl.evaluation.mapper;

import com.zkl.evaluation.model.entity.QuestionTag;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zkl
* @description 针对表【question_tag(题目标签)】的数据库操作Mapper
* @createDate 2025-04-16 18:46:31
* @Entity com.zkl.evaluation.model.entity.QuestionTag
*/
public interface QuestionTagMapper extends BaseMapper<QuestionTag> {

}




