package com.zkl.evaluation.aop;

import com.zkl.evaluation.common.ErrorCode;
import com.zkl.evaluation.exception.BusinessException;
import com.zkl.evaluation.model.entity.ApiLog;
import com.zkl.evaluation.service.ApiLogService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.UUID;

/**
 * 请求响应日志 AOP
 *

 **/
@Aspect
@Component
@Slf4j
public class LogInterceptor {
    @Resource
    private ApiLogService apiLogService;

    /**
     * 执行拦截
     */
    @Around("execution(* com.zkl.evaluation.controller.*.*(..))")
    public Object doInterceptor(ProceedingJoinPoint point) throws Throwable {
        // 计时
        StopWatch stopWatch = new StopWatch();
        stopWatch.start();
        // 获取请求路径
        RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
        HttpServletRequest httpServletRequest = ((ServletRequestAttributes) requestAttributes).getRequest();
        // 生成请求唯一 id
        String requestId = UUID.randomUUID().toString();
        String url = httpServletRequest.getRequestURI();
        String ip = httpServletRequest.getRemoteHost();
        Long userId = (Long)httpServletRequest.getSession().getAttribute("userId");
        // 获取请求参数
        Object[] args = point.getArgs();
        String reqParam = "[" + StringUtils.join(args, ", ") + "]";
        // 输出请求日志
        log.info("request start，id: {}, path: {}, ip: {}, params: {}", requestId, url,
                httpServletRequest.getRemoteHost(), reqParam);
        // 执行原方法
        Object result = point.proceed();
        // 输出响应日志
        stopWatch.stop();
        long totalTimeMillis = stopWatch.getTotalTimeMillis();
        log.info("request end, id: {}, cost: {}ms", requestId, totalTimeMillis);
        /**
         * 存入数据库
         */
//        ApiLog apiLog = new ApiLog();
//        apiLog.setRequestId(requestId);
//        apiLog.setPath(url);
//        apiLog.setIp(ip);
//        apiLog.setParams(reqParam);
//        apiLog.setCost(totalTimeMillis);
//        apiLog.setUserId(userId);
//        if (apiLog.getRequestId() == null) {
//            log.warn("插入api_log前未设置requestId，生成默认值以避免Sharding报错");
//            apiLog.setRequestId(UUID.randomUUID().toString());
//        }
//        apiLogService.save(apiLog);
        return result;
    }

}

