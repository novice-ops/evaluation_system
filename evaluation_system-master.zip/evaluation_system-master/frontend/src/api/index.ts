// @ts-ignore
/* eslint-disable */
// API 更新时间：
// API 唯一标识：
import * as apiLogController from "./apiLogController";
import * as appController from "./appController";
import * as appStatisticController from "./appStatisticController";
import * as fileController from "./fileController";
import * as postController from "./postController";
import * as postFavourController from "./postFavourController";
import * as postThumbController from "./postThumbController";
import * as questionController from "./questionController";
import * as questionInformationController from "./questionInformationController";
import * as scoringResultController from "./scoringResultController";
import * as userController from "./userController";
import * as userAnswerController from "./userAnswerController";
export default {
  apiLogController,
  appController,
  appStatisticController,
  fileController,
  postController,
  postFavourController,
  postThumbController,
  questionController,
  questionInformationController,
  scoringResultController,
  userController,
  userAnswerController,
};
