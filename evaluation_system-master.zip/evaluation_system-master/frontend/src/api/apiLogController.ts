// @ts-ignore
/* eslint-disable */
import request from "@/request";

/** deleteApp POST /api/apiLog/delete */
export async function deleteAppUsingPost(
  body: API.ApiLogDeleteRequest,
  options?: { [key: string]: any }
) {
  return request<API.BaseResponseBoolean_>("/api/apiLog/delete", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}

/** getApiLogByRequestId GET /api/apiLog/get */
export async function getApiLogByRequestIdUsingGet(
  // 叠加生成的Param类型 (非body参数swagger默认没有生成对象)
  params: API.getApiLogByRequestIdUsingGETParams,
  options?: { [key: string]: any }
) {
  return request<API.BaseResponseApiLog_>("/api/apiLog/get", {
    method: "GET",
    params: {
      ...params,
    },
    ...(options || {}),
  });
}

/** listApiLogByPage POST /api/apiLog/list/page */
export async function listApiLogByPageUsingPost(
  body: API.ApiLogQueryRequest,
  options?: { [key: string]: any }
) {
  return request<API.BaseResponsePageApiLog_>("/api/apiLog/list/page", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    data: body,
    ...(options || {}),
  });
}
