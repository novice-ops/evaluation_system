<template>
  <a-row class="globalHeader" align="center" :wrap="false">
    <a-col flex="auto">
      <a-menu
        mode="horizontal"
        :selected-keys="selectedKeys"
        @menu-item-click="doMenuClick"
      >
        <a-menu-item
          key="0"
          :style="{ padding: 0, marginRight: '38px' }"
          disabled
        >
          <div class="titleBar">
            <img class="logo" src="../assets/logo.png" />
            <div class="title">智能测评系统</div>
          </div>
        </a-menu-item>

        <a-menu-item v-for="item in homeRoutes" :key="item.path">
          {{ item.name }}
        </a-menu-item>

        <a-sub-menu title="🔒管理" v-if="loginUserStore.loginUser.userRole == 'admin'">
          <a-menu-item v-for="item in adminRoutes" :key="item.path">
            {{ item.name }}
          </a-menu-item>
        </a-sub-menu>

        <a-menu-item v-for="item in visibleRoutes" :key="item.path">
          {{ item.name }}
        </a-menu-item>

        <a-sub-menu title="💬我的" v-if="loginUserStore.loginUser.id">
          <a-menu-item v-for="item in myRoutes" :key="item.path">
            {{ item.name }}
          </a-menu-item>
        </a-sub-menu>

<!--        <a-sub-menu title="帖子" v-if="loginUserStore.loginUser.id">-->
<!--          <a-menu-item v-for="item in postRoutes" :key="item.path">-->
<!--            {{ item.name }}-->
<!--          </a-menu-item>-->
<!--        </a-sub-menu>-->
      </a-menu>
    </a-col>
    <a-col flex="auto" style="text-align: right; padding-right: 16px">
      <!-- 判断用户是否已登录 -->
      <div v-if="loginUserStore.loginUser.id">

        <a-avatar
          :size="24"
          :image-url="loginUserStore.loginUser.userAvatar"
          :style="{ marginRight: '20px' }"
        />
<!--        <span style="margin-right: 12px">-->
          {{ loginUserStore.loginUser.userName ?? "匿名用户" }}
<!--        </span>-->
        <!-- 登出按钮 -->
        <a-button type="text" @click="doLogout">退出登录</a-button>
      </div>
      <div v-else>
        <a-button type="primary" href="/user/login">登录</a-button>
      </div>
    </a-col>
  </a-row>
</template>

<script setup lang="ts">
import { routes } from "@/router/routes";
import { useRouter } from "vue-router";
import { computed, ref } from "vue";
import { useLoginUserStore } from "@/store/userStore";
import checkAccess from "@/access/checkAccess";
import { userLogoutUsingPost } from "@/api/userController";

// 用户信息
const loginUserStore = useLoginUserStore();

// 过滤可见路由
const visibleRoutes = computed(() => {
  return routes.filter((item) => {
    if (item.meta?.hideInMenu) {
      return false;
    }
    if (!checkAccess(loginUserStore.loginUser, item.meta?.access as string)) {
      return false;
    }
    return true;
  });
});

//下拉路由
const adminRoutes = computed(() => {
  return routes.filter((item) => {
    if (item.meta?.group == "admin") {
      return true;
    }
    if (!checkAccess(loginUserStore.loginUser, item.meta?.access as string)) {
      return false;
    }
    return false;
  });
});
const homeRoutes = computed(() => {
  return routes.filter((item) => {
    if (item.meta?.group == "home") {
      return true;
    }
    if (!checkAccess(loginUserStore.loginUser, item.meta?.access as string)) {
      return false;
    }
    return false;
  });
});
const postRoutes = computed(() => {
  return routes.filter((item) => {
    if (item.meta?.group == "post") {
      return true;
    }
    if (!checkAccess(loginUserStore.loginUser, item.meta?.access as string)) {
      return false;
    }
    return false;
  });
});
const myRoutes = computed(() => {
  return routes.filter((item) => {
    if (item.meta?.group == "my") {
      return true;
    }
    if (!checkAccess(loginUserStore.loginUser, item.meta?.access as string)) {
      return false;
    }
    return false;
  });
});

// 路由
const router = useRouter();

// 当前选中菜单项
const selectedKeys = ref(["/"]);
router.afterEach((to, from, failure) => {
  selectedKeys.value = [to.path];
});

// 点击菜单跳转
const doMenuClick = (key: string) => {
  router.push({ path: key });
};

/**
 * 调用后端登出接口
 */
const doLogout = async () => {
  try {
    const res = await userLogoutUsingPost();
    if (res.data.code === 0) {
      // 登出成功，清空前端用户数据
      console.log("后端返回成功，开始清空store并跳转");
      loginUserStore.loginUser = {};
      router.push("/");
    } else {
      console.error("登出失败", res.data.message);
    }
  } catch (error) {
    console.error("登出接口异常", error);
  }
};
</script>

<style scoped>
.globalHeader {
}
.titleBar {
  display: flex;
  align-items: center;
}
.title {
  color: black;
  margin-left: 16px;
}
.logo {
  height: 48px;
}
</style>
