import { RouteRecordRaw } from "vue-router";
import HomePage from "../views/HomePage.vue";
import UserLayout from "@/layouts/UserLayout.vue";
import ACCESS_ENUM from "@/access/accessEnum";
import NoAuthPage from "@/views/NoAuthPage.vue";
import UserLoginPage from "@/views/user/UserLoginPage.vue";
import UserRegisterPage from "@/views/user/UserRegisterPage.vue";
import AdminUserPage from "@/views/admin/AdminUserPage.vue";
import AdminAppPage from "@/views/admin/AdminAppPage.vue";
import AdminQuestionPage from "@/views/admin/AdminQuestionPage.vue";
import AdminScoringResultPage from "@/views/admin/AdminScoringResultPage.vue";
import AdminUserAnswerPage from "@/views/admin/AdminUserAnswerPage.vue";
import AppDetailPage from "@/views/app/AppDetailPage.vue";
import AddAppPage from "@/views/add/AddAppPage.vue";
import AddQuestionPage from "@/views/add/AddQuestionPage.vue";
import AddScoringResultPage from "@/views/add/AddScoringResultPage.vue";
import DoAnswerPage from "@/views/answer/DoAnswerPage.vue";
import AnswerResultPage from "@/views/answer/AnswerResultPage.vue";
import MyAnswerPage from "@/views/answer/MyAnswerPage.vue";
import AppMyPage from "@/views/admin/AppMyPage.vue";
import component from "*.vue";
import AddAllQuestionPage from "@/views/add/AddAllQuestionPage.vue";
import ApiLogPage from "@/views/admin/ApiLogPage.vue";
import EditQuestion from "@/views/add/EditQuestion.vue";
import LearnPage from "@/views/add/LearnPage.vue";
import UserProfile from "@/views/user/UserProfile.vue";
import PostList from "@/views/post/PostList.vue";
import PostDetail from "@/views/post/PostDetail.vue";
import PostEdit from "@/views/post/PostEdit.vue";
import PostMy from "@/views/post/PostMy.vue";
import AppStatisticPage from "@/views/statistic/AppStatisticPage.vue";
import DoAnswerMultiPage from "@/views/answer/DoAnswerMultiPage.vue";
import DoAnswerFillPage from "@/views/answer/DoAnswerFillPage.vue";
import DoAnswerSubjectivePage from "@/views/answer/DoAnswerSubjectivePage.vue";
import AdminPostPage from "@/views/admin/AdminPostPage.vue";
import HelloWorld from "@/components/HelloWorld.vue";
import PublishPost from "@/views/post/PublishPost.vue";

export const routes: Array<RouteRecordRaw> = [
  {
    path: "/test",
    name: "测试",
    component: HelloWorld,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/",
    name: "📚主页",
    component: HomePage,
    meta: {
      hideInMenu: true,
      group: "home",
    },
  },
  {
    path: "/admin/user",
    name: "👥用户管理",
    component: AdminUserPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/admin/app",
    name: "📖测评活动管理",
    component: AdminAppPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/admin/question",
    name: "📝题目管理",
    component: AdminQuestionPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/admin/scoring_result",
    name: "📊评分管理",
    component: AdminScoringResultPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/admin/user_answer",
    name: "✨回答管理",
    component: AdminUserAnswerPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/admin/post",
    name: "💡帖子管理",
    component: AdminPostPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
      hideInMenu: true,
      group: "admin",
    },
  },
  {
    path: "/post",
    component: PostList,
    name: "🔥帖子广场",
    // meta: {
    //   hideInMenu: true,
    // },
  },
  {
    path: "/post/add",
    name: "发帖",
    component: PublishPost,
    meta: {
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/answer/my",
    name: "🎯我创建的回答",
    component: MyAnswerPage,
    meta: {
      access: ACCESS_ENUM.USER,
      hideInMenu: true,
      group: "my",
    },
  },
  {
    path: "/admin/appMy",
    name: "📚我创建的测评",
    component: AppMyPage,
    meta: {
      access: ACCESS_ENUM.USER,
      hideInMenu: true,
      group: "my",
    },
  },

  {
    path: "/answer/do/single/:appId",
    name: "答题",
    component: DoAnswerPage,
    props: true,
    meta: {
      hideInMenu: true,
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/answer/do/multi/:appId",
    name: "多选答题",
    component: DoAnswerMultiPage,
    props: true,
    meta: {
      hideInMenu: true,
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/answer/do/fill/:appId",
    name: "填空答题",
    component: DoAnswerFillPage,
    props: true,
    meta: {
      hideInMenu: true,
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/answer/do/subjective/:appId",
    name: "简答答题",
    component: DoAnswerSubjectivePage,
    props: true,
    meta: {
      hideInMenu: true,
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/answer/result/:id",
    name: "答题结果",
    component: AnswerResultPage,
    props: true,
    meta: {
      hideInMenu: true,
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/add/app",
    name: "创建测评",
    component: AddAppPage,
    meta: {
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/question/add",
    name: "创建题目外部",
    component: AddAllQuestionPage,
    meta: {
      access: ACCESS_ENUM.USER,
      hideInMenu: true,
    },
  },
  {
    path: "/question/add/:type",
    component: EditQuestion,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/question/add/:appId(\\d+)/:type", // 有 appId 时也能匹配
    component: EditQuestion,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/add/app/:id",
    name: "修改测评活动",
    props: true,
    component: AddAppPage,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/add/question/:appId",
    name: "创建题目",
    component: AddQuestionPage,
    props: true,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/add/scoring_result/:appId",
    name: "创建评分",
    component: AddScoringResultPage,
    props: true,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/noAuth",
    name: "无权限",
    component: NoAuthPage,
    meta: {
      hideInMenu: true,
    },
  },
  {
    path: "/app/detail/:id",
    name: "测评活动详情页",
    props: true,
    component: AppDetailPage,
    meta: {
      hideInMenu: true,
    },
  },

  {
    path: "/admin/learn",
    name: "🚀学习资源",
    component: LearnPage,
    meta: {
      access: ACCESS_ENUM.USER,
    },
  },


  {
    path: "/post/my",
    component: PostMy,
    name: "💡我创建的帖子",
    meta: {
      access: ACCESS_ENUM.USER,
      hideInMenu: true,
      group: "my",
    },
  },

  // {
  //   path: "/user/profile",
  //   name: "个人中心",
  //   component: UserProfile,
  //   meta: {
  //     access: ACCESS_ENUM.USER,
  //   },
  // },
  {
    path: "/app_statistic",
    name: "📊应用统计",
    component: AppStatisticPage,
    meta: {
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/admin/api_log",
    name: "🔒日志",
    component: ApiLogPage,
    meta: {
      access: ACCESS_ENUM.ADMIN,
    },
  },
  {
    path: "/about",
    name: "👤个人中心",
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AboutView.vue"),
    meta: {
      access: ACCESS_ENUM.USER,
    },
  },
  {
    path: "/user",
    name: "用户",
    component: UserLayout,
    children: [
      {
        path: "/user/login",
        name: "用户登录",
        component: UserLoginPage,
      },
      {
        path: "/user/register",
        name: "用户注册",
        component: UserRegisterPage,
      },
    ],
    meta: {
      hideInMenu: true,
    },
  },
];
