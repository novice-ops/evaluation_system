<template>
  <div id="basiclayout">
    <a-layout style="height: 100vh">
      <a-layout-header class="header">
        <GlobalHeader />
      </a-layout-header>
      <a-layout-content class="content">
        <router-view />
      </a-layout-content>
      <a-layout-footer class="footer">
        <a
          href="https://gitee.com/zkl_workspace/evaluation_system"
          target="_blank"
          >基于科大讯飞的智能测评系统设计与实现</a
        >
      </a-layout-footer>
    </a-layout>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
#basiclayout {
}

#basiclayout .header {
  margin-bottom: 16px;
  box-shadow: #eee 1px 1px 5px;
}

#basiclayout .content {
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  box-sizing: border-box;

  background: linear-gradient(to right, #fefefe, #fff);
  margin-bottom: 28px;
  padding: 20px;
}

.footer {
  background: #efefef;
  padding: 16px;
  text-align: center;
}
</style>
<script>
import GlobalHeader from "@/components/GlobalHeader";
export default {
  components: { GlobalHeader },
};
</script>
