<template>
  <a-form :model="form" @submit="goNext" auto-label-width>
    <a-form-item label="测评活动 ID">
      <a-input
        v-model="form.appId"
        placeholder="可为空，稍后再绑定"
        allow-clear
      />
    </a-form-item>

    <a-form-item label="题型">
      <a-radio-group v-model="form.type">
        <a-radio value="single">单选</a-radio>
        <a-radio value="multi">多选</a-radio>
        <a-radio value="fill">填空</a-radio>
        <a-radio value="subjective">简答</a-radio>
      </a-radio-group>
    </a-form-item>

    <a-button type="primary" html-type="submit" :disabled="!form.type">
      下一步
    </a-button>
  </a-form>
</template>

<script setup lang="ts">
import { reactive } from "vue";
import { useRouter } from "vue-router";
const router = useRouter();
const form = reactive<{ appId?: string; type: string }>({ type: "" });

const goNext = () => {
  const { appId, type } = form;
  if (appId) router.push(`/question/add/${appId}/${type}`);
  else router.push(`/question/add/${type}`);
};
</script>
