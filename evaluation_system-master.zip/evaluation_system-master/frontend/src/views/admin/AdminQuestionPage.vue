<template>
  <!-- 搜索表单 + 列设置 -->
  <a-space
    align="center"
    style="width: 100%; justify-content: center; margin-bottom: 16px"
  >
    <a-form :model="formSearchParams" layout="inline" @submit="doSearch">
      <a-form-item field="appId" label="测评活动 id">
        <a-input
          v-model="formSearchParams.appId"
          placeholder="请输入测评活动 id"
          allow-clear
        />
      </a-form-item>
      <a-form-item field="userId" label="用户 id">
        <a-input
          v-model="formSearchParams.userId"
          placeholder="请输入用户 id"
          allow-clear
        />
      </a-form-item>
      <a-form-item field="type" label="题目题型">
        <a-input
          v-model="formSearchParams.type"
          placeholder="请输入题目题型"
          allow-clear
        />
      </a-form-item>
      <a-form-item>
        <a-space>
          <a-button type="primary" html-type="submit">搜索</a-button>
          <!-- 列设置按钮 -->
          <a-popover trigger="click" title="选择要展示的列">
            <template #content>
              <a-checkbox-group v-model="selectedKeys" :options="columnOptions" />
            </template>
            <a-button>列设置</a-button>
          </a-popover>
        </a-space>
      </a-form-item>
    </a-form>
  </a-space>

  <!-- 表格 -->
  <a-table
    :columns="visibleColumns"
    :data="dataList"
    :pagination="{
      showTotal: true,
      pageSize: searchParams.pageSize,
      current: searchParams.current,
      total
    }"
    @page-change="onPageChange"
  >
    <template #questionContent="{ record }">
      <div
        v-for="question in JSON.parse(record.questionContent)"
        :key="question.title"
      >
        {{ question }}
      </div>
    </template>
    <template #createTime="{ record }">
      {{ dayjs(record.createTime).format('YYYY-MM-DD HH:mm:ss') }}
    </template>
    <template #updateTime="{ record }">
      {{ dayjs(record.updateTime).format('YYYY-MM-DD HH:mm:ss') }}
    </template>
    <template #optional="{ record }">
      <a-space>
        <a-button status="danger" @click="doDelete(record)">删除</a-button>
      </a-space>
    </template>
  </a-table>
</template>

<script setup lang="ts">
import { ref, watchEffect, computed } from "vue";
import {
  deleteQuestionUsingPost,
  listQuestionByPageUsingPost,
} from "@/api/questionController";
import API from "@/api";
import message from "@arco-design/web-vue/es/message";
import { dayjs } from "@arco-design/web-vue/es/_utils/date";
import type { CheckboxOption } from "@arco-design/web-vue";

// ------ 列配置相关 ------
interface ColDef {
  key: string;
  title: string;
  dataIndex?: string;
  slotName?: string;
}
const allColumns: ColDef[] = [
  { key: "id",              title: "id",               dataIndex: "id" },
  { key: "questionContent", title: "题目内容",         dataIndex: "questionContent", slotName: "questionContent" },
  { key: "appId",           title: "测评活动 id",      dataIndex: "appId" },
  { key: "userId",          title: "用户 id",          dataIndex: "userId" },
  { key: "createTime",      title: "创建时间",         dataIndex: "createTime", slotName: "createTime" },
  { key: "updateTime",      title: "更新时间",         dataIndex: "updateTime", slotName: "updateTime" },
  { key: "optional",        title: "操作",             slotName: "optional" },
];
// 默认展示的列 key
const defaultKeys = ["questionContent", "appId", "optional"];
const selectedKeys = ref<string[]>([...defaultKeys]);
// 复选框选项
const columnOptions = computed<CheckboxOption[]>(() =>
  allColumns.map(col => ({ label: col.title, value: col.key }))
);
// 根据 selectedKeys 过滤出真正传给 a-table 的 columns
const visibleColumns = computed(() =>
  allColumns
    .filter(col => selectedKeys.value.includes(col.key))
    .map(col => {
      const c: any = { title: col.title, key: col.key };
      if (col.dataIndex) c.dataIndex = col.dataIndex;
      if (col.slotName) c.slotName = col.slotName;
      return c;
    })
);

// ------ 数据加载 & 搜索 & 分页 ------
const formSearchParams = ref<Partial<API.QuestionQueryRequest>>({});
const initSearchParams = { current: 1, pageSize: 10 };
const searchParams = ref<Partial<API.QuestionQueryRequest>>({ ...initSearchParams });
const dataList = ref<API.Question[]>([]);
const total = ref(0);

async function loadData() {
  const res = await listQuestionByPageUsingPost(searchParams.value);
  if (res.data.code === 0) {
    dataList.value = res.data.data?.records || [];
    total.value = res.data.data?.total || 0;
  } else {
    message.error("获取数据失败：" + res.data.message);
  }
}

function doSearch() {
  searchParams.value = { ...initSearchParams, ...formSearchParams.value };
}

function onPageChange(page: number) {
  searchParams.value = { ...searchParams.value, current: page };
}

async function doDelete(record: API.Question) {
  if (!record.id) return;
  const res = await deleteQuestionUsingPost({ id: record.id });
  if (res.data.code === 0) {
    loadData();
  } else {
    message.error("删除失败：" + res.data.message);
  }
}

// 监听并加载
watchEffect(loadData);
</script>
