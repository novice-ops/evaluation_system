<template>
  <div id="noAuthPage">无权限</div>
</template>

<script>
export default {
  name: "NoAuthPage",
};
</script>

<style scoped></style>
